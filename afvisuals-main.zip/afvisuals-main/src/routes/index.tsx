import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import avatar from "@/assets/avatar.png";
import proof1 from "@/assets/proof1.jpeg";
import proof2 from "@/assets/proof2.jpeg";
import proof3 from "@/assets/proof3.jpeg";
import proof4 from "@/assets/proof4.jpeg";
import proof5 from "@/assets/proof5.jpeg";
import stats1 from "@/assets/stats1.png";
import stats2 from "@/assets/stats2.png";
import stats3 from "@/assets/stats3.png";

export const Route = createFileRoute("/")({
  component: Index,
});

const nav = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Work", href: "#work" },
  { label: "Proof", href: "#proof" },
  { label: "Contact", href: "#contact" },
];

const skills = [
  { name: "Web Development", value: 95 },
  { name: "Digital Marketing", value: 92 },
  { name: "Facebook / Meta Ads", value: 90 },
  { name: "UI / UX Design", value: 85 },
  { name: "E-commerce Setup", value: 94 },
  { name: "Performance Marketing", value: 88 },
];

const work = [
  { tag: "Fitness / DTC", name: "MiFitness", desc: "Performance fitness storefront engineered for repeat purchase.", url: "https://mifitness.store" },
  { tag: "Wellness", name: "Aquimi Liquid", desc: "Hydration brand with editorial product storytelling and global checkout.", url: "https://aquimiliquid.com" },
  { tag: "Marketplace", name: "Alhamad Mart", desc: "Multi-category mart built for conversion and logistics at scale.", url: "https://alhamadmart.store" },
  { tag: "Apparel — UAE", name: "AF Dubai", desc: "Premium apparel build with international logistics integration.", url: "https://afduba.myshopify.com" },
  { tag: "Healthcare", name: "Marham", desc: "Healthcare platform connecting patients to verified specialists.", url: "https://marham.pk" },
  { tag: "MedTech", name: "TryMedwe", desc: "Modern medical commerce experience with clean clinical UI.", url: "https://trymedwe.com" },
];

const contacts = [
  { label: "WhatsApp", value: "+92 316 0415760", href: "https://wa.me/923160415760" },
  { label: "Call", value: "+92 316 0415760", href: "tel:+923160415760" },
  { label: "Email", value: "afbusinesscentres@gmail.com", href: "mailto:afbusinesscentres@gmail.com" },
  { label: "Instagram", value: "AfVisuals", href: "https://www.instagram.com/afvisuals_15?igsh=bHRnNmdiZmdnYnZh" },
  { label: "LinkedIn", value: "LinkedIn", href: "https://www.linkedin.com/in/abdullah-developer-80a262415?utm_source=share_via&utm_content=profile&utm_medium=member_android" },
];

function useParallax() {
  const [y, setY] = useState(0);
  useEffect(() => {
    let raf = 0;
    const on = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setY(window.scrollY));
    };
    window.addEventListener("scroll", on, { passive: true });
    return () => { window.removeEventListener("scroll", on); cancelAnimationFrame(raf); };
  }, []);
  return y;
}

function Reveal({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setShown(true); io.disconnect(); }}, { threshold: 0.15 });
    io.observe(el); return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} style={{ transitionDelay: `${delay}ms` }}
      className={`transition-all duration-[900ms] ease-[cubic-bezier(.2,.7,.2,1)] ${shown ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"} ${className}`}>
      {children}
    </div>
  );
}

function Index() {
  const y = useParallax();

  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* Nav */}
      <header className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-[min(960px,92vw)]">
        <nav className="flex items-center justify-between rounded-full border border-border bg-card/70 backdrop-blur-xl px-5 py-2.5">
          <a href="#top" className="flex items-center gap-2 text-sm font-medium tracking-widest">
            <span className="size-1.5 rounded-full bg-primary shadow-[0_0_12px_var(--color-primary)]" />
            AFVisuals
          </a>
          <div className="hidden md:flex items-center gap-7 text-[12px] uppercase tracking-[0.18em] text-muted-foreground">
            {nav.map(n => <a key={n.href} href={n.href} className="soft-link">{n.label}</a>)}
          </div>
          <a href="#contact" className="text-xs font-medium px-4 py-1.5 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-colors duration-300">
            Hire
          </a>
        </nav>
      </header>

      {/* Hero */}
      <section id="top" className="relative pt-40 pb-28 px-6">
        <div className="absolute inset-0 grid-bg pointer-events-none" />
        <div
          aria-hidden
          className="absolute right-[-10%] top-10 size-[520px] rounded-full opacity-40 blur-3xl"
          style={{ background: "radial-gradient(circle, var(--color-primary) 0%, transparent 60%)", transform: `translateY(${y * 0.15}px)` }}
        />
        <div className="relative mx-auto max-w-6xl grid lg:grid-cols-[1.2fr_1fr] gap-14 items-center">
          <div>
            <Reveal>
              <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-muted-foreground rounded-full border border-border px-3 py-1.5">
                <span className="size-1.5 rounded-full bg-primary animate-pulse" />
                Available for premium projects
              </span>
            </Reveal>
            <Reveal delay={120}>
              <h1 className="mt-7 text-5xl md:text-7xl leading-[1.02] font-medium">
                Abdullah
                <span className="block text-gradient">& Anees</span>
              </h1>
            </Reveal>
            <Reveal delay={240}>
              <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-muted-foreground">
                Digital Marketing & Web Development specialists — crafting cinematic digital experiences and scalable e-commerce systems.
              </p>
            </Reveal>
            <Reveal delay={360}>
              <div className="mt-9 flex flex-wrap gap-3">
                <a href="#contact" className="liquid-btn group inline-flex items-center gap-2 rounded-full text-primary-foreground px-6 py-3 text-sm font-medium">
                  Contact us
                  <span className="transition-transform duration-500 group-hover:translate-x-1">→</span>
                </a>
                <a href="#work" className="liquid-outline inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm">
                  View work
                </a>
              </div>
            </Reveal>
            <Reveal delay={480}>
              <div className="mt-14 grid grid-cols-3 max-w-md gap-6">
                {[
                  { v: "8+", l: "E-com builds" },
                  { v: "$2M+", l: "Ad spend" },
                  { v: "5★", l: "Client rating" },
                ].map(s => (
                  <div key={s.l}>
                    <div className="text-3xl font-display text-primary">{s.v}</div>
                    <div className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground mt-1">{s.l}</div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>

          {/* Avatar — hover parallax */}
          <Reveal delay={300} className="relative justify-self-center">
            <HoverParallaxAvatar />
          </Reveal>
        </div>
      </section>

      {/* About */}
      <section id="about" className="relative py-28 px-6">
        <div className="mx-auto max-w-6xl grid md:grid-cols-[1fr_2fr] gap-12">
          <Reveal>
            <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">About</div>
          </Reveal>
          <div>
            <Reveal>
              <h2 className="text-3xl md:text-5xl leading-[1.08]">Five years turning brands into systems.</h2>
            </Reveal>
            <Reveal delay={120}>
              <div className="mt-8 space-y-5 text-[15px] leading-relaxed text-muted-foreground max-w-2xl">
                <p>We're a digital marketing & web development duo focused on crafting premium e-commerce experiences and the performance engines behind them — from architecture and UI to ad systems that compound.</p>
                <p>We've shipped 8+ live storefronts, managed multi-six-figure ad budgets across Meta and Google, and built funnels that respect both the customer and the bottom line.</p>
                <p className="text-foreground/80">The work is quiet. The numbers are loud.</p>
              </div>
            </Reveal>
            <Reveal delay={240}>
              <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { t: "Web Dev", s: "React · Next · Shopify" },
                  { t: "Ads", s: "Meta · Google · TikTok" },
                  { t: "Design", s: "UI · UX · Brand" },
                  { t: "E-com", s: "Funnels · CRO · Logistics" },
                ].map(c => (
                  <div key={c.t} className="rounded-2xl border border-border bg-card/40 p-4 glow-card">
                    <div className="text-sm font-medium">{c.t}</div>
                    <div className="text-[11px] text-muted-foreground mt-1">{c.s}</div>
                  </div>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Skills */}
      <section id="skills" className="relative py-28 px-6">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Capabilities</div>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="mt-3 text-3xl md:text-5xl max-w-2xl">Engineered for scale & conversion.</h2>
          </Reveal>
          <div className="mt-14 grid md:grid-cols-2 gap-x-12 gap-y-8">
            {skills.map((s, i) => <SkillBar key={s.name} {...s} delay={i * 80} />)}
          </div>
        </div>
      </section>

      {/* Work */}
      <section id="work" className="relative py-28 px-6">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Selected Work</div>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="mt-3 text-3xl md:text-5xl max-w-2xl">Live e-commerce case studies.</h2>
          </Reveal>
          <div className="mt-14 grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            {work.map((w, i) => (
              <Reveal key={w.name} delay={i * 70}>
                <a href={w.url} target="_blank" rel="noreferrer"
                   className="group block rounded-2xl border border-border bg-card/40 p-6 h-full glow-card">
                  <div className="text-[11px] uppercase tracking-[0.2em] text-primary/80">{w.tag}</div>
                  <div className="mt-3 text-xl font-display">{w.name}</div>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{w.desc}</p>
                  <div className="mt-6 flex items-center justify-between text-xs text-muted-foreground">
                    <span className="truncate">{new URL(w.url).hostname.replace("www.","")}</span>
                    <span className="text-primary transition-transform duration-500 group-hover:translate-x-1">Visit live →</span>
                  </div>
                </a>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Proof */}
      <section id="proof" className="relative py-28 px-6">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Proof of Work</div>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="mt-3 text-3xl md:text-5xl max-w-2xl">Real client conversations & dashboards.</h2>
          </Reveal>
          <div className="mt-14 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[
              { src: proof1, label: "Client — Oasismall" },
              { src: proof2, label: "Client — Nature Zone" },
              { src: proof3, label: "Client — Glamour Hub" },
              { src: proof4, label: "Client — Grab Nest" },
              { src: proof5, label: "Client — M&W Trading" },
              { src: stats1, label: "Dashboard — Rs 7.2M" },
              { src: stats2, label: "Dashboard — PKR 2.4M" },
              { src: stats3, label: "Dashboard — AED 35K" },
            ].map((p, i) => (
              <Reveal key={i} delay={i * 60}>
                <div className="group relative aspect-[3/4] overflow-hidden rounded-2xl border border-border bg-card/40 glow-card">
                  <img src={p.src} alt={p.label} loading="lazy"
                       className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-[1.04]" />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/85 via-background/10 to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3 text-[11px] uppercase tracking-[0.18em] text-foreground/90">{p.label}</div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="relative py-28 px-6">
        <div className="mx-auto max-w-6xl">
          <Reveal>
            <div className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Direct Channel</div>
          </Reveal>
          <Reveal delay={100}>
            <h2 className="mt-3 text-3xl md:text-5xl max-w-2xl">Let's build something unforgettable.</h2>
          </Reveal>

          <div className="mt-14 grid lg:grid-cols-[1.1fr_1fr] gap-8">
            <Reveal>
              <form className="rounded-2xl border border-border bg-card/40 p-6 md:p-8 space-y-4"
                    onSubmit={(e) => { e.preventDefault(); window.location.href = "mailto:afbusinesscentres@gmail.com"; }}>
                <Field label="Your name"><input required className="w-full bg-transparent outline-none text-sm py-2 border-b border-border focus:border-primary transition-colors" placeholder="John Doe" /></Field>
                <Field label="Email"><input required type="email" className="w-full bg-transparent outline-none text-sm py-2 border-b border-border focus:border-primary transition-colors" placeholder="you@brand.com" /></Field>
                <Field label="Project brief"><textarea required rows={4} className="w-full bg-transparent outline-none text-sm py-2 border-b border-border focus:border-primary transition-colors resize-none" placeholder="Tell us about your store, audience and goals…" /></Field>
                <button type="submit" className="liquid-btn mt-2 inline-flex items-center gap-2 rounded-full text-primary-foreground px-6 py-3 text-sm font-medium">
                  Send Inquiry →
                </button>
              </form>
            </Reveal>

            <div className="grid sm:grid-cols-2 gap-3 content-start">
              {contacts.map((c, i) => (
                <Reveal key={c.label} delay={i * 70}>
                  <a href={c.href} target={c.href.startsWith("http") ? "_blank" : undefined} rel="noreferrer"
                     className="group block rounded-2xl border border-border bg-card/40 p-5 glow-card">
                    <div className="text-[11px] uppercase tracking-[0.2em] text-primary/80">{c.label}</div>
                    <div className="mt-2 text-sm truncate">{c.value}</div>
                    <div className="mt-4 text-xs text-muted-foreground transition-transform duration-500 group-hover:translate-x-1">→</div>
                  </a>
                </Reveal>
              ))}
            </div>
          </div>

          <div className="mt-20 pt-8 border-t border-border flex flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
            <div>© {new Date().getFullYear()} Abdullah Azhar & Anees Ahmad — AF Visuals.</div>
            <div className="flex gap-5">
              {nav.map(n => <a key={n.href} href={n.href} className="soft-link">{n.label}</a>)}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-[11px] uppercase tracking-[0.2em] text-muted-foreground mb-1">{label}</span>
      {children}
    </label>
  );
}

function SkillBar({ name, value, delay }: { name: string; value: number; delay: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [w, setW] = useState(0);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setTimeout(() => setW(value), delay); io.disconnect(); }
    }, { threshold: 0.4 });
    io.observe(el); return () => io.disconnect();
  }, [value, delay]);
  return (
    <div ref={ref}>
      <div className="flex items-baseline justify-between">
        <div className="text-sm">{name}</div>
        <div className="text-xs text-primary font-medium tabular-nums">{w}%</div>
      </div>
      <div className="mt-3 h-[3px] rounded-full bg-muted overflow-hidden">
        <div className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-[width] duration-[1400ms] ease-[cubic-bezier(.2,.7,.2,1)]"
             style={{ width: `${w}%` }} />
      </div>
    </div>
  );
}

function HoverParallaxAvatar() {
  const ref = useRef<HTMLDivElement>(null);
  const [t, setT] = useState({ x: 0, y: 0, rx: 0, ry: 0 });
  const [hover, setHover] = useState(false);
  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    setT({ x: px * 18, y: py * 18, rx: -py * 8, ry: px * 8 });
  };
  const reset = () => { setHover(false); setT({ x: 0, y: 0, rx: 0, ry: 0 }); };
  return (
    <div
      ref={ref}
      onMouseEnter={() => setHover(true)}
      onMouseMove={onMove}
      onMouseLeave={reset}
      className="relative"
      style={{ perspective: "1000px" }}
    >
      <div
        className="absolute -inset-6 rounded-full bg-primary/10 blur-2xl transition-opacity duration-500"
        style={{ opacity: hover ? 1 : 0.55 }}
      />
      <div
        className="relative size-[340px] md:size-[400px] rounded-full overflow-hidden border border-border transition-transform duration-300 ease-out"
        style={{
          transform: `rotateX(${t.rx}deg) rotateY(${t.ry}deg) translate3d(${t.x * 0.4}px, ${t.y * 0.4}px, 0)`,
          transformStyle: "preserve-3d",
        }}
      >
        <img
          src={avatar}
          alt="Abdullah Azhar"
          className="absolute inset-0 size-full object-cover transition-transform duration-300 ease-out"
          style={{ transform: `translate3d(${t.x}px, ${t.y}px, 0) scale(${hover ? 1.08 : 1})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
      </div>
      <div className="absolute -left-6 top-10 px-3 py-1.5 rounded-full bg-card/80 backdrop-blur border border-border text-xs animate-float">Web Dev</div>
      <div className="absolute -right-4 top-1/2 px-3 py-1.5 rounded-full bg-card/80 backdrop-blur border border-border text-xs animate-float" style={{ animationDelay: "1.5s" }}>Meta Ads</div>
      <div className="absolute left-8 -bottom-2 px-3 py-1.5 rounded-full bg-card/80 backdrop-blur border border-border text-xs animate-float" style={{ animationDelay: "3s" }}>E-commerce</div>
    </div>
  );
}
